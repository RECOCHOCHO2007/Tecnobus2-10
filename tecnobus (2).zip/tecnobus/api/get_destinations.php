<?php
// get_destinations.php
require_once 'db_connection.php';
header("Content-Type: application/json; charset=UTF-8");

$response = ["success" => false, "message" => "Ocurrió un error inesperado."];

try {
    $sql = "SELECT id, name FROM destinations";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $destinations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($destinations) {
        $response = ["success" => true, "destinations" => $destinations];
    } else {
        $response = ["success" => false, "message" => "No se encontraron destinos."];
    }

} catch (PDOException $e) {
    $response["message"] = "Error en la base de datos: " . $e->getMessage();
}

echo json_encode($response);
?>