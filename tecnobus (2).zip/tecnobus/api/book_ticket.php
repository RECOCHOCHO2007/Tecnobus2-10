<?php
// check_session.php
session_start();
header("Content-Type: application/json; charset=UTF-8");

if (isset($_SESSION['user_id'])) {
    echo json_encode(["isAuthenticated" => true]);
} else {
    echo json_encode(["isAuthenticated" => false]);
}
?>