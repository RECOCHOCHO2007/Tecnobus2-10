<?php
// db_connection.php

// --- Configuración de seguridad ---
define("DB_SERVERNAME", "localhost");
define("DB_USERNAME", "root");
define("DB_PASSWORD", "");
define("DB_NAME", "tecnobus_db");

// Define el entorno de la aplicación.
define("ENVIRONMENT", "development");

// --- Encabezados de la API ---
if (ENVIRONMENT === 'production') {
    header("Access-Control-Allow-Origin: https://www.tudominio.com");
} else {
    header("Access-Control-Allow-Origin: *");
}
header("Content-Type: application/json; charset=UTF-8");

// Crear conexión
$conn = new mysqli(DB_SERVERNAME, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Verificar conexión
if ($conn->connect_error) {
    error_log("Connection failed: " . $conn->connect_error);
    
    if (ENVIRONMENT === 'production') {
        die(json_encode(["success" => false, "message" => "Ocurrió un error en la conexión a la base de datos."]));
    } else {
        die(json_encode(["success" => false, "message" => "Connection failed: " . $conn->connect_error]));
    }
}
?>