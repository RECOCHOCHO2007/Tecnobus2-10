<?php
// add_funds.php
session_start();
require_once 'db_connection.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "message" => "Acceso no autorizado. Por favor, inicia sesión."]);
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents("php://input"));
    $amount = $data->amount ?? 0;

    if (!is_numeric($amount) || $amount <= 0) {
        echo json_encode(["success" => false, "message" => "Cantidad inválida."]);
        $conn->close();
        exit();
    }

    $stmt = $conn->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
    $stmt->bind_param("di", $amount, $user_id);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Saldo actualizado exitosamente."]);
    } else {
        echo json_encode(["success" => false, "message" => "Error al actualizar saldo: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["success" => false, "message" => "Método de solicitud no permitido."]);
}
?>