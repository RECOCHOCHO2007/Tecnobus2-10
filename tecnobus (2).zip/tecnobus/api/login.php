<?php
// login.php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); 

// Configuración de la Base de Datos (AJUSTA ESTO)
$host = 'localhost';
$db   = 'tecnobus_db'; // <--- Nombre de tu base de datos
$user = 'root';        // <--- Usuario de tu MySQL
$pass = '';            // <--- Contraseña de tu MySQL

$dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

// Comprobar método POST y datos JSON
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['email']) || !isset($data['password'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Faltan datos de email o contraseña.']);
    exit();
}

$email = $data['email'];
$password = $data['password'];
$user = null;

try {
     $pdo = new PDO($dsn, $user, $pass, $options);
     
     $stmt = $pdo->prepare("SELECT id, name, email, password_hash, balance FROM users WHERE email = ?");
     $stmt->execute([$email]);
     $user_data = $stmt->fetch();

     if ($user_data && password_verify($password, $user_data['password_hash'])) {
        // Login exitoso
        $user = [
            'id' => $user_data['id'],
            'name' => $user_data['name'],
            'email' => $user_data['email'],
            'balance' => $user_data['balance']
        ];
        
        http_response_code(200);
        echo json_encode(['success' => true, 'message' => 'Login exitoso.', 'user' => $user]);
     } else {
        // Fallo de autenticación
        http_response_code(401);
        echo json_encode(['success' => false, 'message' => 'Email o contraseña incorrectos.']);
     }

} catch (\PDOException $e) {
     // Error de DB
     http_response_code(500);
     echo json_encode(['success' => false, 'message' => 'Error del servidor al procesar la solicitud.']);
     // Puedes loguear $e->getMessage() para debug
}
?>