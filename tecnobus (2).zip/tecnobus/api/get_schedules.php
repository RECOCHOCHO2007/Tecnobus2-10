<?php
// get_schedules.php - CÓDIGO PARA CARGAR HORARIOS DESDE LA DB

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); 

// Configuración de la Base de Datos (¡AJUSTA ESTO!)
$host = 'localhost';
$db   = 'tecnobus_db'; // <--- Nombre de tu base de datos
$user = 'root';        // <--- Usuario de tu MySQL
$pass = '';            // <--- Contraseña de tu MySQL

$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
     $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
     http_response_code(500);
     // Mensaje de error para el front-end
     echo json_encode(['success' => false, 'message' => 'Error de conexión a la base de datos.']);
     exit();
}

// Consulta usando JOIN para obtener los nombres de Origen y Destino
$stmt = $pdo->query("
    SELECT 
        s.id, 
        s.company,
        s.departure_time, 
        s.departure_day,
        s.duration,
        s.price, 
        origin.name AS origin,
        destination.name AS destination
    FROM 
        schedules s
    INNER JOIN 
        destinations origin ON s.origin_id = origin.id
    INNER JOIN 
        destinations destination ON s.destination_id = destination.id
    ORDER BY s.departure_time ASC
");

$schedules = $stmt->fetchAll();

// Devolver la respuesta
http_response_code(200);
echo json_encode(['success' => true, 'schedules' => $schedules]);

?>