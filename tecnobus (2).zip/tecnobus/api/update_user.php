<?php
// update_user.php
session_start(); // **CAMBIO:** Inicia la sesión
require_once 'db_connection.php';

// **CAMBIO:** Autenticación y Autorización
// Verifica si el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "message" => "Acceso no autorizado. Por favor, inicia sesión."]);
    $conn->close();
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents("php://input"));

    // **CAMBIO:** Obtiene el ID del usuario de la sesión, NO de la solicitud
    $user_id = $_SESSION['user_id']; 
    
    $name = $data->name ?? null;
    $email = $data->email ?? null;
    $phone = $data->phone ?? null;

    $update_fields = [];
    $bind_types = "";
    $bind_values = [];

    if ($name !== null) {
        $update_fields[] = "name = ?";
        $bind_types .= "s";
        $bind_values[] = $name;
    }
    if ($email !== null) {
        // **CAMBIO:** Valida el formato del email antes de actualizar
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(["success" => false, "message" => "El formato del email es inválido."]);
            $conn->close();
            exit();
        }
        $update_fields[] = "email = ?";
        $bind_types .= "s";
        $bind_values[] = $email;
    }
    if ($phone !== null) {
        $update_fields[] = "phone = ?";
        $bind_types .= "s";
        $bind_values[] = $phone;
    }

    if (empty($update_fields)) {
        echo json_encode(["success" => false, "message" => "No hay campos para actualizar."]);
        $conn->close();
        exit();
    }

    $query = "UPDATE users SET " . implode(", ", $update_fields) . " WHERE id = ?";
    $bind_types .= "i";
    $bind_values[] = $user_id; // **CAMBIO:** Usa el ID de la sesión

    $stmt = $conn->prepare($query);
    $stmt->bind_param($bind_types, ...$bind_values);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(["success" => true, "message" => "Información actualizada correctamente."]);
        } else {
            echo json_encode(["success" => true, "message" => "No se realizó ningún cambio."]);
        }
    } else {
        if ($conn->errno == 1062) {
            echo json_encode(["success" => false, "message" => "El email ingresado ya está en uso por otra cuenta."]);
        } else {
            echo json_encode(["success" => false, "message" => "Error al actualizar información: " . $stmt->error]);
        }
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["success" => false, "message" => "Método de solicitud no permitido."]);
}
?>