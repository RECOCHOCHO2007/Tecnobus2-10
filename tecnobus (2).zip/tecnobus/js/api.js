// js/api.js - Versión final con getSchedules

const API_BASE_URL = 'http://localhost/tecnobus/'; 

const postData = async (endpoint, data) => {
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });

        if (!response.ok) {
            const code = response.status;
            let message = `Error de servidor. Código: ${code}`;
            if (code === 404) {
                message = `Error de conexión: Archivo PHP no encontrado (404) en la ruta ${API_BASE_URL}${endpoint}`;
            }
            console.error(message);
            return { success: false, code, message };
        }

        return await response.json();
    } catch (error) {
        console.error('Error de red/conexión:', error);
        return { success: false, code: 500, message: 'Error de conexión con el servidor.' };
    }
};

const fetchData = async (endpoint) => {
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`);
        if (!response.ok) {
            console.error(`Error de red: ${response.status} en ${endpoint}`);
            return { success: false, code: response.status, message: 'Error de red o servidor.' };
        }
        return await response.json();
    } catch (error) {
        console.error('Error de conexión:', error);
        return { success: false, code: 500, message: 'Error de conexión con el servidor.' };
    }
};


export const login = (email, password) => {
    return postData('login.php', { email, password }); 
};

export const register = (name, email, password) => {
    return postData('register.php', { name, email, password });
};

export const logout = async () => {
    return { success: true };
};

// NUEVA FUNCIÓN PARA OBTENER HORARIOS
export const getSchedules = () => {
    return fetchData('get_schedules.php'); 
};