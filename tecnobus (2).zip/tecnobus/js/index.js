import { checkAuthStatus } from './auth.js';
import { initializeMap } from './main.js';

const authView = document.getElementById('auth-view');
const appContainer = document.getElementById('app-container');
const mainViews = document.querySelectorAll('.main-view');
const navLinks = document.querySelectorAll('.main-nav a');
const settingsMenuItems = document.querySelectorAll('.settings-menu li');
const contentSections = document.querySelectorAll('.content-section');
const backToSchedulesBtn = document.getElementById('back-to-schedules-btn');

export const changeView = (viewId) => {
    if (viewId === 'app-container') {
        if (authView) authView.classList.remove('active');
        if (appContainer) appContainer.classList.add('active');
    } else if (viewId === 'auth-view') {
        if (appContainer) appContainer.classList.remove('active');
        if (authView) authView.classList.add('active');
    }
};

const switchAppView = (viewId) => {
    if (mainViews) {
        mainViews.forEach(view => {
            view.classList.remove('active');
        });
        const targetView = document.getElementById(viewId);
        if (targetView) {
            targetView.classList.add('active');
        }
    }
    if (navLinks) {
        navLinks.forEach(navLink => navLink.classList.remove('active'));
        const targetLink = document.querySelector(`.main-nav a[data-view="${viewId.replace('-view', '')}"]`);
        if (targetLink) {
            targetLink.classList.add('active');
        }
    }
};

const switchSettingsSection = (targetId) => {
    if (contentSections) {
        contentSections.forEach(section => {
            section.classList.remove('active');
        });
        const targetSection = document.getElementById(`${targetId}-content`);
        if (targetSection) {
            targetSection.classList.add('active');
        }
    }
    if (settingsMenuItems) {
        settingsMenuItems.forEach(item => {
            item.classList.remove('active');
        });
        const targetMenuItem = document.querySelector(`[data-target="${targetId}"]`);
        if (targetMenuItem) {
            targetMenuItem.classList.add('active');
        }
    }
};

if (navLinks) {
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const viewId = link.getAttribute('data-view');
            switchAppView(`${viewId}-view`);
        });
    });
}

if (settingsMenuItems) {
    settingsMenuItems.forEach(item => {
        item.addEventListener('click', () => {
            const targetId = item.getAttribute('data-target');
            switchSettingsSection(targetId);
        });
    });
}

if (backToSchedulesBtn) {
    backToSchedulesBtn.addEventListener('click', () => {
        switchAppView('viajes-view');
    });
}

document.addEventListener('DOMContentLoaded', () => {
    checkAuthStatus();
    if (document.getElementById('map')) {
        initializeMap();
    }
});

const themeRadios = document.querySelectorAll('input[name="theme"]');
themeRadios.forEach(radio => {
    radio.addEventListener('change', (e) => {
        document.body.classList.remove('dark-theme', 'light-theme');
        document.body.classList.add(`${e.target.value}-theme`);
    });
});