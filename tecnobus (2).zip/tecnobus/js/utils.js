// js/utils.js

/**
 * Muestra un mensaje de feedback.
 * @param {HTMLElement} element - Elemento DOM (ej: login-feedback).
 * @param {string} message - El texto del mensaje.
 * @param {boolean} show - True para mostrar, False para ocultar.
 * @param {string} type - 'success' o 'error'.
 */
export const showFeedback = (element, message, show, type = 'error') => {
    if (element) {
        element.textContent = message;
        element.classList.remove('success', 'error', 'hidden');
        if (show) {
            element.classList.add(type);
        } else {
            element.classList.add('hidden');
        }
    }
};

// Función para simplificar la ocultación
export const hideFeedback = (element) => {
    showFeedback(element, '', false);
};