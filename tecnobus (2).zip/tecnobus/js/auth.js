// js/auth.js - VERSIÓN CORREGIDA Y FUNCIONAL

// --- 1. Importaciones ---
import { showFeedback } from './utils.js'; 
import { login, register } from './api.js'; 
import { handleAuthState } from './app.js'; 
import { getTranslation } from './i18n.js'; // Necesaria para el título de la vista

// --- 2. Funciones de Control de Vistas ---

const toggleForms = (showLogin) => {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const authTitle = document.getElementById('auth-title');

    if (loginForm && registerForm && authTitle) {
        if (showLogin) {
            loginForm.classList.remove('hidden');
            registerForm.classList.add('hidden');
            // Usamos traducción para el título
            authTitle.textContent = getTranslation('app_title_login'); 
        } else {
            loginForm.classList.add('hidden');
            registerForm.classList.remove('hidden');
            // Usamos traducción para el título
            authTitle.textContent = getTranslation('app_title_register');
        }
        // Limpia mensajes
        showFeedback(document.getElementById('login-feedback'), '', false);
        showFeedback(document.getElementById('register-feedback'), '', false);
    }
};

// Función principal que inicializa todos los Event Listeners
const initAuth = () => {
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const showRegisterBtn = document.getElementById('show-register-btn');
    const showLoginBtn = document.getElementById('show-login-btn');
    const loginFeedback = document.getElementById('login-feedback');
    const registerFeedback = document.getElementById('register-feedback');
    const authView = document.getElementById('auth-view');

    if (!authView) {
        return; 
    }

    // --- 3. Event Listeners de Cambio de Vista ---
    if (showRegisterBtn) {
        showRegisterBtn.addEventListener('click', (e) => {
            e.preventDefault();
            toggleForms(false); // Mostrar Registro
        });
    }

    if (showLoginBtn) {
        showLoginBtn.addEventListener('click', (e) => {
            e.preventDefault();
            toggleForms(true); // Mostrar Login
        });
    }

    // --- 4. Lógica de LOGIN ---
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => { 
            e.preventDefault();
            showFeedback(loginFeedback, '', false); 
            
            const email = loginForm.querySelector('#login-email').value;
            const password = loginForm.querySelector('#login-password').value;
            
            const result = await login(email, password);
            
            if (result.success) {
                // Éxito: Guardar estado y cargar la vista de la aplicación
                localStorage.setItem('isAuthenticated', 'true');
                localStorage.setItem('user', JSON.stringify(result.user));
                handleAuthState(true, result.user); 
            } else {
                showFeedback(loginFeedback, result.message || "Credenciales incorrectas o error de servidor.", true, 'error');
            }
        });
    }


    // --- 5. Lógica de REGISTRO ---
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            showFeedback(registerFeedback, '', false);
            
            const name = registerForm.querySelector('#register-name').value;
            const email = registerForm.querySelector('#register-email').value;
            const password = registerForm.querySelector('#register-password').value;
            const confirmPassword = registerForm.querySelector('#register-confirm-password').value;

            if (password !== confirmPassword) {
                showFeedback(registerFeedback, 'Las contraseñas no coinciden.', true, 'error');
                return;
            }

            const result = await register(name, email, password); 
            
            if (result.success) {
                showFeedback(registerFeedback, result.message || "Registro exitoso. ¡Inicia sesión!", true, 'success');
                setTimeout(() => {
                    toggleForms(true); // Mostrar Login
                }, 2000);
            } else {
                showFeedback(registerFeedback, result.message || "Error al intentar registrar el usuario.", true, 'error');
            }
        });
    }
}

// SOLUCIÓN AL TypeError: Se ejecuta solo cuando el DOM está listo.
document.addEventListener('DOMContentLoaded', initAuth);

// Verificación inicial de sesión al cargar el DOM
document.addEventListener('DOMContentLoaded', () => {
    const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
    const user = localStorage.getItem('user');
    if (isAuthenticated && user) {
        try {
            // handleAuthState se llama aquí.
            handleAuthState(true, JSON.parse(user));
        } catch (e) {
            console.error("Error al cargar sesión previa:", e);
        }
    } else {
        // Asegura que la vista Auth se muestre con la traducción correcta
        const authTitle = document.getElementById('auth-title');
        if (authTitle) {
             authTitle.textContent = getTranslation('app_title_login'); 
        }
        handleAuthState(false);
    }
});