// js/app.js - VERSIÓN FINAL CON IDIOMA, NAVEGACIÓN Y CARGA DE HORARIOS DESDE API

import { logout, getSchedules } from './api.js'; 
import { getTranslation, setLanguage, getCurrentLanguage } from './i18n.js'; 

let map = null;
let allSchedules = []; // Almacenará todos los horarios obtenidos de la API

// --- Funciones de Traducción ---
const applyTranslations = () => {
    document.querySelectorAll('[data-i18n]').forEach(element => {
        const key = element.getAttribute('data-i18n');
        element.textContent = getTranslation(key);
    });
    const langSelect = document.getElementById('language-select');
    if (langSelect) {
        langSelect.querySelector('option[value="es"]').textContent = getTranslation('language_option_es');
        langSelect.querySelector('option[value="en"]').textContent = getTranslation('language_option_en');
        langSelect.querySelector('option[value="pt"]').textContent = getTranslation('language_option_pt');
        document.querySelector('label[for="language-select"]').textContent = getTranslation('language_select_label');
    }
    if (map) {
        map.eachLayer(layer => {
            if (layer.getPopup && layer.getPopup()) {
                layer.getPopup().setContent(getTranslation('map_popup_text'));
            }
        });
    }
};

const setupLanguageListener = () => {
    const languageSelect = document.getElementById('language-select');
    if (languageSelect) {
        languageSelect.value = getCurrentLanguage();
        languageSelect.addEventListener('change', (e) => {
            const newLang = e.target.value;
            setLanguage(newLang);
            applyTranslations(); 
        });
    }
};

// --- Funciones de Horarios ---

const loadAndRenderSchedules = async () => {
    const result = await getSchedules();
    const tableBody = document.getElementById('schedules-table-body');

    if (result.success) {
        allSchedules = result.schedules;
        fillScheduleSelectors(allSchedules);
        renderSchedulesTable(allSchedules);
    } else {
        console.error("Error al cargar horarios:", result.message);
        if(tableBody) tableBody.innerHTML = `<tr><td colspan="8" style="text-align:center; color: red; padding: 20px;">Error al cargar horarios: ${result.message}</td></tr>`;
        allSchedules = [];
    }
};

const fillScheduleSelectors = (schedules) => {
    const originSelect = document.getElementById('search-origin');
    const destinationSelect = document.getElementById('search-destination');

    if (!originSelect || !destinationSelect) return;

    const origins = [...new Set(schedules.map(s => s.origin))].sort();
    const destinations = [...new Set(schedules.map(s => s.destination))].sort();

    const populateSelect = (selectElement, options) => {
        const defaultOption = selectElement.querySelector('option[value=""]');
        selectElement.innerHTML = '';
        if (defaultOption) selectElement.appendChild(defaultOption);

        options.forEach(option => {
            const opt = document.createElement('option');
            opt.value = option;
            opt.textContent = option;
            selectElement.appendChild(opt);
        });
    };

    populateSelect(originSelect, origins);
    populateSelect(destinationSelect, destinations);
};

const renderSchedulesTable = (schedules) => {
    const tableBody = document.getElementById('schedules-table-body');
    const noSchedulesMsg = document.getElementById('no-schedules-message');

    if (!tableBody) return;
    
    tableBody.innerHTML = '';

    if (schedules.length === 0) {
        tableBody.innerHTML = '';
        if (noSchedulesMsg) noSchedulesMsg.classList.remove('hidden');
        return;
    }
    if (noSchedulesMsg) noSchedulesMsg.classList.add('hidden');


    schedules.forEach(schedule => {
        const row = document.createElement('tr');
        // Asegúrate de que los nombres de los campos coincidan con los de tu SQL y PHP
        row.innerHTML = `
            <td>${schedule.origin}</td>
            <td>${schedule.destination}</td>
            <td>${schedule.company}</td>
            <td>${schedule.departure_day}</td>
            <td>${schedule.departure_time ? schedule.departure_time.substring(0, 5) : 'N/A'}</td> 
            <td>${schedule.duration}</td>
            <td>$${parseFloat(schedule.price).toFixed(2)}</td>
            <td><button class="btn btn-small btn-primary buy-ticket-btn" data-schedule-id="${schedule.id}">Comprar</button></td>
        `;
        tableBody.appendChild(row);
    });

    document.querySelectorAll('.buy-ticket-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const scheduleId = e.target.getAttribute('data-schedule-id');
            const schedule = schedules.find(s => s.id == scheduleId);
            if (schedule) {
                console.log(`Comprar boleto para ${schedule.origin} a ${schedule.destination} a las ${schedule.departure_time}`);
                alert(`¡Boleto para ${schedule.origin} a ${schedule.destination} (${schedule.company}) reservado! (Simulado)`);
            }
        });
    });
};

const setupScheduleSearch = () => {
    const form = document.getElementById('schedule-search-form');
    const clearBtn = document.getElementById('clear-search-btn');

    if (form) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const origin = document.getElementById('search-origin').value;
            const destination = document.getElementById('search-destination').value;

            const filteredSchedules = allSchedules.filter(s => {
                const matchOrigin = origin === "" || s.origin === origin;
                const matchDestination = destination === "" || s.destination === destination;
                return matchOrigin && matchDestination;
            });

            renderSchedulesTable(filteredSchedules);
        });
    }

    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            document.getElementById('search-origin').value = '';
            document.getElementById('search-destination').value = '';
            renderSchedulesTable(allSchedules);
        });
    }
};


// --- Funciones de la Aplicación General ---

const updateProfileUI = (user) => {
    const profileCardName = document.getElementById('profile-card-name');
    const profileCardEmail = document.getElementById('profile-card-email');
    const infoNombre = document.getElementById('info-nombre');
    const infoEmail = document.getElementById('info-email');
    const saldoDisplay = document.getElementById('saldo-usuario-display');
    
    if (user && profileCardName) profileCardName.textContent = user.name || 'Usuario';
    if (user && profileCardEmail) profileCardEmail.textContent = user.email || 'email@ejemplo.com';
    
    if (user && infoNombre) infoNombre.value = user.name || '';
    if (user && infoEmail) infoEmail.value = user.email || '';
    
    if (user && saldoDisplay) saldoDisplay.textContent = user.balance || '0.00';
};

const initMap = () => {
    if (map) {
        map.remove();
        map = null;
    }

    const mapElement = document.getElementById('map');
    if (!mapElement) return;

    const montevideo = [-34.9033, -56.1882]; 

    map = L.map('map').setView(montevideo, 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    L.marker(montevideo).addTo(map)
        .bindPopup(getTranslation('map_popup_text'))
        .openPopup();
};

const setupInternalNavigation = () => {
    const mainViews = document.querySelectorAll('.main-view');
    const navLinks = document.querySelectorAll('.main-nav a[data-view]');

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const targetViewId = e.target.closest('a').getAttribute('data-view') + '-view';

            mainViews.forEach(view => {
                view.classList.add('hidden');
                view.classList.remove('active');
            });

            const targetView = document.getElementById(targetViewId);
            if (targetView) {
                targetView.classList.remove('hidden');
                targetView.classList.add('active');
            }

            if (targetViewId === 'perfil-view') {
                setTimeout(initMap, 50);
            }
        });
    });

    const settingsMenuItems = document.querySelectorAll('.settings-menu li');
    const contentSections = document.querySelectorAll('.content-section');

    settingsMenuItems.forEach(item => {
        item.addEventListener('click', () => {
            const targetId = item.getAttribute('data-target') + '-content';

            settingsMenuItems.forEach(i => i.classList.remove('active'));
            contentSections.forEach(section => section.classList.remove('active', 'visible'));
            contentSections.forEach(section => section.classList.add('hidden'));

            item.classList.add('active');
            const targetContent = document.getElementById(targetId);
            
            if (targetContent) {
                targetContent.classList.remove('hidden');
                targetContent.classList.add('active', 'visible');
            }
        });
    });
};


export const initAppView = (user) => {
    updateProfileUI(user);
    setupInternalNavigation();
    setupLanguageListener(); 
    initMap();

    // Carga los horarios desde la API
    loadAndRenderSchedules(); 
    setupScheduleSearch();
};


export const handleAuthState = (isAuthenticated, user = null) => {
    const authView = document.getElementById('auth-view');
    const appContainer = document.getElementById('app-container');

    applyTranslations(); 

    if (isAuthenticated) {
        if (authView) authView.classList.add('hidden'); 
        if (appContainer) appContainer.classList.remove('hidden'); 
        
        initAppView(user); 
        
    } else {
        if (authView) authView.classList.remove('hidden'); 
        if (appContainer) appContainer.classList.add('hidden'); 

        if (map) {
             map.remove();
             map = null;
        }
    }
};

const setupLogoutListener = () => {
    const logoutBtn = document.getElementById('logout-btn');

    if (logoutBtn) {
        logoutBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            
            await logout(); 
            
            localStorage.removeItem('isAuthenticated');
            localStorage.removeItem('user');
            
            handleAuthState(false);
        });
    }
}


document.addEventListener('DOMContentLoaded', () => {
    setupLogoutListener();
    applyTranslations();

    const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
    let user = null;
    try {
        const userJson = localStorage.getItem('user');
        if (userJson) {
            user = JSON.parse(userJson);
        }
    } catch (e) {
        console.error("Error al parsear datos de usuario de localStorage:", e);
        isAuthenticated = false; 
    }
    
    handleAuthState(isAuthenticated, user);
});