// js/i18n.js - Sistema de Internacionalización

// Objeto que contiene todas las traducciones
const translations = {
    'es': {
        // --- Navegación Principal ---
        'nav_viajes': 'VIAJES',
        'nav_boletos': 'BOLETOS',
        'nav_perfil': 'PERFIL',
        'nav_fondos': 'AÑADIR FONDOS',
        'nav_salir': 'Salir',
        
        // --- Perfil - Menú Lateral ---
        'menu_info': 'Tu información',
        'menu_cuenta': 'Datos de tu cuenta',
        'menu_seguridad': 'Seguridad',
        'menu_tarjetas': 'Tarjetas',
        'menu_apariencia': 'Apariencia',
        'menu_idioma': 'Idioma',

        // --- Perfil - Títulos de Contenido ---
        'title_info': 'Tu información',
        'title_cuenta': 'Datos de tu cuenta',
        'title_seguridad': 'Seguridad',
        'title_apariencia': 'Apariencia',
        'title_idioma': 'Idioma',

        // --- Perfil - Info ---
        'label_nombre': 'Nombre:',
        'label_email': 'Email:',
        'label_telefono': 'Teléfono:',
        'btn_guardar': 'Guardar Cambios',
        
        // --- Otros elementos de UI y Textos de App ---
        'map_title': 'MAPA GPS (Uruguay)',
        'map_popup_text': 'Tu ubicación actual (simulada).',
        'app_title_login': 'Iniciar Sesión', 
        'app_title_register': 'Crear Cuenta',
        'language_select_label': 'Selecciona el idioma:',
        'language_option_es': 'Español (Uruguay)',
        'language_option_en': 'English',
        'language_option_pt': 'Português',
        
    },
    'en': {
        // --- Navegación Principal ---
        'nav_viajes': 'TRIPS',
        'nav_boletos': 'TICKETS',
        'nav_perfil': 'PROFILE',
        'nav_fondos': 'ADD FUNDS',
        'nav_salir': 'Logout',
        
        // --- Perfil - Menú Lateral ---
        'menu_info': 'Your Information',
        'menu_cuenta': 'Account Data',
        'menu_seguridad': 'Security',
        'menu_tarjetas': 'Cards',
        'menu_apariencia': 'Appearance',
        'menu_idioma': 'Language',

        // --- Perfil - Títulos de Contenido ---
        'title_info': 'Your Information',
        'title_cuenta': 'Account Data',
        'title_seguridad': 'Security',
        'title_apariencia': 'Appearance',
        'title_idioma': 'Language',

        // --- Perfil - Info ---
        'label_nombre': 'Name:',
        'label_email': 'Email:',
        'label_telefono': 'Phone:',
        'btn_guardar': 'Save Changes',
        
        // --- Otros elementos de UI y Textos de App ---
        'map_title': 'GPS MAP (Uruguay)',
        'map_popup_text': 'Your current location (simulated).',
        'app_title_login': 'Log In',
        'app_title_register': 'Create Account',
        'language_select_label': 'Select language:',
        'language_option_es': 'Español (Uruguay)',
        'language_option_en': 'English',
        'language_option_pt': 'Português',
    },
    'pt': {
        // --- Navegación Principal ---
        'nav_viajes': 'VIAGENS',
        'nav_boletos': 'BILHETES',
        'nav_perfil': 'PERFIL',
        'nav_fondos': 'ADICIONAR FUNDOS',
        'nav_salir': 'Sair',
        
        // --- Perfil - Menú Lateral ---
        'menu_info': 'Sua Informação',
        'menu_cuenta': 'Dados da Conta',
        'menu_seguridad': 'Segurança',
        'menu_tarjetas': 'Cartões',
        'menu_apariencia': 'Aparência',
        'menu_idioma': 'Linguagem',

        // --- Perfil - Títulos de Contenido ---
        'title_info': 'Sua Informação',
        'title_cuenta': 'Dados da Conta',
        'title_seguridad': 'Segurança',
        'title_apariencia': 'Aparência',
        'title_idioma': 'Linguagem',

        // --- Perfil - Info ---
        'label_nombre': 'Nome:',
        'label_email': 'Email:',
        'label_telefono': 'Telefone:',
        'btn_guardar': 'Salvar Alterações',
        
        // --- Otros elementos de UI y Textos de App ---
        'map_title': 'MAPA GPS (Uruguai)',
        'map_popup_text': 'Sua localização atual (simulada).',
        'app_title_login': 'Fazer Login',
        'app_title_register': 'Criar Conta',
        'language_select_label': 'Selecione o idioma:',
        'language_option_es': 'Español (Uruguay)',
        'language_option_en': 'English',
        'language_option_pt': 'Português',
    }
};

let currentLang = localStorage.getItem('appLang') || 'es';

export const getTranslation = (key) => {
    return translations[currentLang][key] || key;
};

export const setLanguage = (lang) => {
    if (translations[lang]) {
        currentLang = lang;
        localStorage.setItem('appLang', lang);
        return true;
    }
    return false;
};

export const getCurrentLanguage = () => {
    return currentLang;
};