document.addEventListener('DOMContentLoaded', () => {
    
    // 🚨 RUTA BASE ESTABLECIDA: Asume que la carpeta se llama 'proyecto'
    const BASE_URL = '/proyecto/'; 
    
    // --- 1. REFERENCIAS A ELEMENTOS CRÍTICOS ---
    const authView = document.getElementById('auth-view');
    const appContainer = document.getElementById('app-container');
    const mainViewContainer = document.getElementById('main-view-container'); 
    
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const loginFeedback = document.getElementById('login-feedback');
    const registerFeedback = document.getElementById('register-feedback');
    const showRegisterBtn = document.getElementById('show-register-btn');
    const showLoginBtn = document.getElementById('show-login-btn');
    const navLinks = document.querySelectorAll('.main-nav ul li a.nav-link');
    const adminLink = document.getElementById('admin-link'); 
    const logoutBtn = document.getElementById('logout-btn'); 
    
    // Almacenamiento local de datos (SIMULADO)
    let USER_BALANCE = 500.00; 

    // ----------------------------------------------------------------------
    // --- FUNCIONES DE UTILIDAD ---
    // ----------------------------------------------------------------------

    /** Muestra un mensaje de feedback en los formularios de autenticación. */
    function showFeedback(element, message, type = 'error') {
        element.textContent = message;
        element.style.display = 'block';
        element.className = 'form-feedback ' + (type === 'success' ? 'success' : (type === 'loading' ? 'loading' : 'error'));
    }

    // Alternar vistas de Login/Registro
    showRegisterBtn?.addEventListener('click', (e) => {
        e.preventDefault();
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
        loginFeedback.style.display = 'none';
        registerFeedback.style.display = 'none';
    });

    showLoginBtn?.addEventListener('click', (e) => {
        e.preventDefault();
        registerForm.style.display = 'none';
        loginForm.style.display = 'block';
        loginFeedback.style.display = 'none';
        registerFeedback.style.display = 'none';
    });

    // ----------------------------------------------------------------------
    // --- LÓGICA DE INICIALIZACIÓN DE VISTAS ---
    // ----------------------------------------------------------------------

    /** Lógica para inicializar la vista de Viajes (Búsqueda de Horarios). */
    function initializeViajesView() {
        console.log('Vista de Viajes/Búsqueda inicializada.');
        // Se asegura de que los IDs existan antes de usarlos
        const origenSelect = document.getElementById('origen-select');
        const destinoSelect = document.getElementById('destino-select');
        const buscarBtn = document.getElementById('buscar-horarios-btn');
        const resultsContainer = document.getElementById('schedule-results');

        // ... [Lógica interna de initializeViajesView] ...

        // --- DATOS SIMULADOS ---
        const DEPARTAMENTOS_UY = ["Artigas", "Canelones", "Montevideo", "Maldonado", "Salto", "Rocha"];
        const HORARIOS_SIMULADOS = [
            { id: 1, hora: "08:30", duracion: "4h 15m", precio: 590, asientos: 45 },
            { id: 2, hora: "11:00", duracion: "4h 00m", precio: 620, asientos: 12 },
            { id: 3, hora: "15:45", duracion: "4h 30m", precio: 580, asientos: 8 },
            { id: 4, hora: "20:00", duracion: "4h 05m", precio: 650, asientos: 31 }
        ];

        function loadDestinations() {
            if (!origenSelect || !destinoSelect) return;
            const destinations = [...DEPARTAMENTOS_UY].sort(); 
            [origenSelect, destinoSelect].forEach(select => {
                select.innerHTML = '<option value="" disabled selected>Seleccione</option>'; 
                destinations.forEach(city => {
                    const option = document.createElement('option');
                    option.value = city;
                    option.textContent = city;
                    select.appendChild(option);
                });
            });
            origenSelect.value = "Montevideo";
            destinoSelect.value = "Maldonado";
        }

        function renderScheduleResults(origen, destino, schedules) {
            let html = '';
            if (!resultsContainer) return; // Validación extra
            if (schedules.length === 0) {
                 html = `<div class="schedule-disclaimer">No se encontraron horarios para ${origen} a ${destino}.</div>`;
            } else {
                html += `<p class="schedule-route-info">Ruta: <strong>${origen} <i class="fas fa-arrow-right"></i> ${destino}</strong></p>`;

                schedules.forEach(item => {
                    html += `
                        <div class="schedule-item" data-trip-id="${item.id}" data-origen="${origen}" data-destino="${destino}">
                            <div><i class="fas fa-clock"></i> Salida: <strong>${item.hora}</strong></div>
                            <div><i class="fas fa-dollar-sign"></i> Precio: <strong>$${item.precio}</strong></div>
                            <div><i class="fas fa-chair"></i> Asientos Libres: <strong>${item.asientos}</strong></div>
                            <button class="btn btn-success btn-small select-seat-btn" 
                                    data-id="${item.id}" data-hora="${item.hora}" data-precio="${item.precio}"
                                    ${item.asientos === 0 ? 'disabled' : ''}>
                                ${item.asientos === 0 ? 'Agotado' : 'Seleccionar Asiento'}
                            </button>
                        </div>
                    `;
                });
            }
            resultsContainer.innerHTML = html;
            attachSelectSeatListeners();
        }

        function handleSearchClick() {
            const origen = origenSelect.value;
            const destino = destinoSelect.value;
            if (resultsContainer) resultsContainer.innerHTML = ''; 

            if (!origen || !destino || origen === destino) {
                if(resultsContainer) resultsContainer.innerHTML = `<div class="schedule-disclaimer error">Selecciona un origen y destino diferentes.</div>`;
                return;
            }
            if(resultsContainer) resultsContainer.innerHTML = '<div class="schedule-disclaimer loading">Buscando horarios...</div>';

            // Simular la llamada al servidor
            setTimeout(() => {
                renderScheduleResults(origen, destino, HORARIOS_SIMULADOS);
            }, 500);
        }
        
        function attachSelectSeatListeners() {
            document.querySelectorAll('.select-seat-btn').forEach(button => {
                button.addEventListener('click', (e) => {
                    e.preventDefault();
                    const item = e.currentTarget.closest('.schedule-item').dataset; 
                    
                    // Guardar los datos del viaje en localStorage
                    localStorage.setItem('selectedTrip', JSON.stringify({ 
                        tripId: item.tripId, 
                        hora: e.currentTarget.dataset.hora, 
                        precio: parseFloat(e.currentTarget.dataset.precio),
                        origen: item.origen, 
                        destino: item.destino 
                    }));
                    
                    // Cambiar a la vista de Boletos/Asientos
                    loadView('boletos'); 
                });
            });
        }

        loadDestinations();
        buscarBtn?.addEventListener('click', handleSearchClick);
        setTimeout(handleSearchClick, 100); 
    }
    
    /** Lógica para inicializar la vista de Boletos (Selección de Asientos y Compra). */
    function initializeBoletosView() { 
        console.log('Vista Boletos inicializada.');
        const tripData = JSON.parse(localStorage.getItem('selectedTrip'));
        
        // 🚨 CORRECCIÓN: Verifica que todos los IDs existen al inicio de la función
        const infoEl = document.getElementById('trip-info');
        const seatGrid = document.getElementById('seat-grid');
        const seatInfo = document.getElementById('selected-seat-info');
        const buyBtn = document.getElementById('buy-ticket-btn');
        const balanceDisplay = document.getElementById('current-balance-boletos');
        
        let selectedSeat = null;
        
        // Si algún elemento es null, salimos para evitar errores.
        if (!infoEl || !seatGrid || !seatInfo || !buyBtn || !balanceDisplay) {
             console.error("Error de inicialización de Boletos: Faltan elementos HTML críticos (IDs).");
             return;
        }

        if (tripData) {
            infoEl.innerHTML = `Viaje: <strong>${tripData.origen} a ${tripData.destino}</strong> | Salida: <strong>${tripData.hora}</strong> | Precio: <strong>$${tripData.precio}</strong>`;
            balanceDisplay.textContent = `$${USER_BALANCE.toFixed(2)}`;
        }
        
        // Simular asientos (4 filas de 10 asientos)
        function renderSeats() {
            seatGrid.innerHTML = ''; // Si seatGrid es null, aquí falla (Corregido arriba)
            const seatsPerRow = 4;
            const totalRows = 10;
            const takenSeats = [3, 7, 15, 20];

            for (let i = 1; i <= totalRows * seatsPerRow; i++) {
                const seat = document.createElement('div');
                seat.className = 'seat';
                seat.textContent = i;
                seat.dataset.seatNumber = i;

                if (takenSeats.includes(i)) {
                    seat.classList.add('taken');
                } else {
                    seat.addEventListener('click', handleSeatClick);
                }
                seatGrid.appendChild(seat);
            }
        }

        function updateSeatDisplay(seatNumber) {
            seatInfo.innerHTML = `Asiento Seleccionado: <strong>${seatNumber}</strong>. Total a Pagar: <strong>$${tripData.precio.toFixed(2)}</strong>.`;
            buyBtn.disabled = false;
        }

        function handleSeatClick(e) {
            document.querySelectorAll('.seat').forEach(s => s.classList.remove('selected'));
            e.target.classList.add('selected');
            selectedSeat = e.target.dataset.seatNumber;
            updateSeatDisplay(selectedSeat);
        }

        buyBtn.addEventListener('click', handleBuyTicket); // BuyBtn no es null
        
        function handleBuyTicket() {
            if (!selectedSeat || !tripData) {
                alert("Por favor, selecciona un asiento y un viaje.");
                return;
            }

            if (USER_BALANCE < tripData.precio) {
                alert(`Saldo insuficiente. Necesitas $${tripData.precio.toFixed(2)} y tienes $${USER_BALANCE.toFixed(2)}.`);
                return;
            }

            if (confirm(`¿Confirmas la compra del asiento ${selectedSeat} por $${tripData.precio.toFixed(2)}?`)) {
                // Simulación de transacción exitosa
                USER_BALANCE -= tripData.precio;
                localStorage.removeItem('selectedTrip');
                
                alert(`¡Compra exitosa! Tu saldo restante es de $${USER_BALANCE.toFixed(2)}.`);
                
                loadView('perfil'); 
            }
        }

        renderSeats();
    }
    
    /** Lógica para inicializar la vista de Añadir Fondos. */
    function initializeFondosView() { 
        console.log('Vista Fondos inicializada.');
        // 🚨 CORRECCIÓN: Verifica que todos los IDs existen
        const balanceDisplay = document.getElementById('current-balance-fondos');
        const addFundsForm = document.getElementById('add-funds-form');
        const amountInput = document.getElementById('funds-amount');
        
        if (!balanceDisplay || !addFundsForm || !amountInput) {
            console.error("Error de inicialización de Fondos: Faltan elementos HTML críticos (IDs).");
            return;
        }
        
        balanceDisplay.textContent = `$${USER_BALANCE.toFixed(2)}`;
        
        addFundsForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const amount = parseFloat(amountInput.value);
            
            if (isNaN(amount) || amount <= 0) {
                alert("Por favor, ingresa una cantidad válida.");
                return;
            }
            
            // Simulación de depósito
            USER_BALANCE += amount;
            balanceDisplay.textContent = `$${USER_BALANCE.toFixed(2)}`;
            alert(`$${amount.toFixed(2)} añadidos. Saldo actual: $${USER_BALANCE.toFixed(2)}`);
            amountInput.value = '';
        });
    }

    /** Lógica para inicializar la vista de Perfil. */
    function initializePerfilView() { 
        console.log('Vista Perfil inicializada.');
        // 🚨 CORRECCIÓN: Verifica que el ID existe
        const profileBalanceDisplay = document.getElementById('profile-balance-display');
        
        if (profileBalanceDisplay) {
            profileBalanceDisplay.textContent = `$${USER_BALANCE.toFixed(2)}`;
        } else {
            console.error("Error de inicialización de Perfil: Falta ID 'profile-balance-display'.");
        }
    }

    function initializeBoletosView() { /* (Se omite la definición, ver arriba) */ }
    function initializeFondosView() { /* (Se omite la definición, ver arriba) */ }
    function initializePerfilView() { /* (Se omite la definición, ver arriba) */ }
    
    // ----------------------------------------------------------------------
    // --- LÓGICA DE CARGA DINÁMICA DE VISTAS (Router simple) ---
    // ----------------------------------------------------------------------
    
    async function loadView(viewName) {
        const path = `views/${viewName}.html`;

        try {
            const response = await fetch(path);
            if (!response.ok) {
                throw new Error(`Error ${response.status}: No se pudo cargar la vista ${viewName}`);
            }
            const html = await response.text();
            mainViewContainer.innerHTML = html;
            
            // Ejecutar lógica de inicialización específica
            switch(viewName) {
                case 'perfil':
                    initializePerfilView();
                    break;
                case 'viajes':
                    initializeViajesView();
                    break;
                case 'boletos':
                    initializeBoletosView();
                    break;
                case 'fondos':
                    initializeFondosView();
                    break;
                default:
                    mainViewContainer.innerHTML = `<h1>Vista No Encontrada: ${viewName}</h1>`;
                    break;
            }

            // Activar enlace en la navegación principal
            navLinks.forEach(nav => nav.parentElement.classList.remove('active'));
            const activeLink = document.querySelector(`.main-nav ul li a.nav-link[data-view="${viewName}"]`);
            if (activeLink) activeLink.parentElement.classList.add('active');

        } catch (error) {
            console.error('Error al cargar la vista:', error);
            mainViewContainer.innerHTML = `<div class="error-message">🚨 Error cargando la vista: ${viewName}. Asegúrate que el archivo existe en la carpeta /views/.</div>`;
        }
    }
    
    // ... [Lógica de autenticación AJAX y checkSessionAndLoadApp (sin cambios)] ...
    // --- MANEJO DE AUTENTICACIÓN Y SESIÓN (AJAX ESTABLE) ---

    function showAuthView() {
        authView.style.display = 'flex';
        appContainer.style.display = 'none';
        loginForm?.reset();
        registerForm?.reset();
        loginFeedback.style.display = 'none';
        registerFeedback.style.display = 'none';
    }

    function handleSuccessfulLogin(role) {
        authView.style.display = 'none';
        appContainer.style.display = 'flex'; 
        
        // Lógica de visualización basada en ROLES
        if (role === 'admin') {
            if (adminLink) adminLink.style.display = 'list-item';
            loadView('perfil'); 
        } else { 
            if (adminLink) adminLink.style.display = 'none';
            loadView('viajes'); // Carga la vista principal de la aplicación
        }
    }
    
    // Evento de navegación
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const viewName = link.getAttribute('data-view');
            loadView(viewName);
        });
    });

    // Evento de Salir (Logout)
    logoutBtn?.addEventListener('click', async (e) => {
        e.preventDefault();
        try {
            await fetch(BASE_URL + 'logout.php'); 
            showAuthView(); 
        } catch (error) {
            console.error('Error al cerrar sesión:', error);
            alert('No se pudo cerrar la sesión.');
        }
    });

    // --- AJAX DE AUTENTICACIÓN (Rutas estables) ---

    // A. Lógica de Registro
    if (registerForm) {
        registerForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            registerFeedback.style.display = 'none';
            showFeedback(registerFeedback, 'Registrando usuario...', 'loading');

            const formData = new FormData(registerForm); 
            
            try {
                const response = await fetch(BASE_URL + 'register.php', { method: 'POST', body: formData });
                const textResponse = await response.text(); 
                
                if (!response.ok) throw new Error(`Error HTTP ${response.status}.`);
                if (!textResponse.trim().startsWith('{')) throw new Error("Formato de respuesta inválido.");

                const data = JSON.parse(textResponse); 
                
                if (data.success) {
                    showFeedback(registerFeedback, data.message, 'success');
                    setTimeout(() => showLoginBtn.click(), 1500); 
                } else {
                    showFeedback(registerFeedback, data.message);
                }
            } catch (error) {
                console.error('Error en la solicitud de registro:', error);
                showFeedback(registerFeedback, 'Error de conexión o problema de servidor: ' + error.message);
            }
        });
    }
    
    // B. Lógica de Login
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) { 
            e.preventDefault();
            loginFeedback.style.display = 'none';
            showFeedback(loginFeedback, 'Verificando credenciales...', 'loading');

            const formData = new FormData(loginForm);
            
            try {
                const response = await fetch(BASE_URL + 'login.php', { method: 'POST', body: formData });
                const textResponse = await response.text(); 
                
                if (!response.ok) throw new Error(`Error HTTP ${response.status}.`);
                if (!textResponse.trim().startsWith('{')) throw new Error("Formato de respuesta inválido.");

                const data = JSON.parse(textResponse); 
                
                if (data.success) {
                    showFeedback(loginFeedback, data.message, 'success');
                    setTimeout(() => handleSuccessfulLogin(data.user_role), 500); 
                } else {
                    showFeedback(loginFeedback, data.message);
                }
            } catch (error) {
                console.error('Error al iniciar sesión:', error);
                showFeedback(loginFeedback, 'Error de conexión o problema de servidor: ' + error.message);
            }
        });
    }
    
    // --- VERIFICACIÓN DE SESIÓN INICIAL ---
    async function checkSessionAndLoadApp() {
        try {
            const response = await fetch(BASE_URL + 'check_session.php'); 
            const textResponse = await response.text();
            
            if (!textResponse.trim().startsWith('{')) {
                showAuthView();
                return;
            }
            
            const data = JSON.parse(textResponse);

            if (data.loggedin) {
                handleSuccessfulLogin(data.rol);
            } else {
                showAuthView();
            }
        } catch (error) {
            console.error('Error al verificar sesión:', error);
            showAuthView();
        }
    }
    
    checkSessionAndLoadApp();
});