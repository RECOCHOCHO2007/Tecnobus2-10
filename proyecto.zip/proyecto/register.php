<?php
// register.php (Corregido para usar la conexión simple)

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');
require_once 'db_connection.php'; 

// Inicializar respuesta JSON de fallo por defecto
$response = ['success' => false, 'message' => 'Ocurrió un error inesperado.'];

try {
    // 1. Obtener y sanitizar datos del formulario
    $nombre = trim($_POST['nombre'] ?? '');
    $email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // 2. Validación de campos
    if (empty($nombre) || empty($email) || empty($password)) {
        $response['message'] = 'Por favor, completa todos los campos.';
        echo json_encode($response);
        exit;
    }
    if ($password !== $confirm_password) {
        $response['message'] = 'Las contraseñas no coinciden.';
        echo json_encode($response);
        exit;
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $response['message'] = 'Formato de email inválido.';
        echo json_encode($response);
        exit;
    }

    // 3. Hashear la contraseña
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    $rol = 'usuario'; 

    // 4. Verificar si el email ya existe
    $sql_check = "SELECT id FROM usuarios WHERE email = ?";
    $stmt_check = $mysqli->prepare($sql_check);
    
    if (!$stmt_check) throw new Exception("Error al preparar check: " . $mysqli->error);
    
    $stmt_check->bind_param("s", $email);
    $stmt_check->execute();
    $stmt_check->store_result();

    if ($stmt_check->num_rows > 0) {
        $response['message'] = 'El email ya está registrado. Intenta iniciar sesión.';
    } else {
        // 5. Insertar el nuevo usuario
        $sql_insert = "INSERT INTO usuarios (nombre, email, password_hash, rol) VALUES (?, ?, ?, ?)";
        $stmt_insert = $mysqli->prepare($sql_insert);
        
        if (!$stmt_insert) throw new Exception("Error al preparar insert: " . $mysqli->error);
        
        $stmt_insert->bind_param("ssss", $nombre, $email, $password_hash, $rol);
        
        if ($stmt_insert->execute()) {
            $response = ['success' => true, 'message' => '¡Registro exitoso! Ya puedes iniciar sesión.'];
        } else {
            throw new Exception("Fallo en la ejecución de inserción: " . $stmt_insert->error);
        }
        $stmt_insert->close();
    }

    $stmt_check->close();

} catch (Exception $e) {
    // 6. Manejo de excepciones
    $response['message'] = 'Error interno del sistema durante el registro.';
    error_log("Fallo crítico en register.php: " . $e->getMessage());
} finally {
    // 7. Cerrar la conexión
    if (isset($mysqli)) {
        $mysqli->close();
    }
}

echo json_encode($response);
?>