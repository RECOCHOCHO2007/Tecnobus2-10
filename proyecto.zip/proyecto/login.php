<?php
// login.php

// 1. Iniciar la sesión (CRÍTICO: debe ir al inicio)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');
require_once 'db_connection.php'; 

// Inicializar respuesta JSON de fallo
$response = ['success' => false, 'message' => 'Ocurrió un error inesperado.'];

// 2. Obtener y validar datos
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($email) || empty($password)) {
    $response['message'] = 'Por favor, completa todos los campos.';
    echo json_encode($response);
    exit;
}

// 3. Preparar la consulta para buscar el usuario
$sql = "SELECT id, password_hash, rol FROM usuarios WHERE email = ?"; 
$stmt = $mysqli->prepare($sql);

if (!$stmt) {
    $response['message'] = 'Error interno del servidor.';
    error_log("Error de preparación SQL en login: " . $mysqli->error);
    echo json_encode($response);
    exit;
}

$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // 4. Usuario no encontrado
    $response['message'] = 'Email o contraseña incorrectos.';
} else {
    $user = $result->fetch_assoc();
    $stored_hash = $user['password_hash']; 

    // 5. Verificar la contraseña
    if (password_verify($password, $stored_hash)) {
        
        // 6. Contraseña correcta: Establecer variables de sesión
        $_SESSION['loggedin'] = true;
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_rol'] = $user['rol'];
        
        $response = [
            'success' => true, 
            'message' => 'Inicio de sesión exitoso.', 
            'user_role' => $user['rol'] // Enviamos el rol
        ];
        
    } else {
        // 7. Contraseña incorrecta
        $response['message'] = 'Email o contraseña incorrectos.';
    }
}

$stmt->close();
$mysqli->close();

// 8. Enviar respuesta final
echo json_encode($response);
?>