<?php
// ELIGE UNA CONTRASEÑA FÁCIL QUE VAS A USAR PARA INICIAR SESIÓN. 
// Por ejemplo: 'AdminSeguro1'
$password_plana_elegida = "admin1234"; 

// Genera el hash
$hash_generado = password_hash($password_plana_elegida, PASSWORD_DEFAULT);

echo "<h2>Contraseña Plana Elegida: " . $password_plana_elegida . "</h2>";
echo "<p>HASH GENERADO (Cópialo COMPLETAMENTE, incluyendo \$2y\$):</p>";
echo "<textarea rows='3' cols='60'>" . $hash_generado . "</textarea>";
?>