<?php
// check_session.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

$is_logged = isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true;
$rol = $_SESSION['user_rol'] ?? 'usuario'; 

echo json_encode([
    'loggedin' => $is_logged,
    'rol' => $rol
]);
?>